# Facilitator Guide | Week 11 | Profiling for Data Quality

**When:** Saturday, 30 May 2026, 1pm UK
**Where:** Zoom
**Duration:** 75 to 80 minutes
**Tutor:** Kelechi Odoemena

---

## The One-Sentence Framing

Last week we *looked* at data. This week we turn what we find into *repeatable checks that return pass or fail*. If students leave with that distinction, the session worked.

---

## Pre-Session Checklist (15 min before)

- [ ] Open Codespaces and run `seed.sql` to refresh BootcampDB
- [ ] Smoke test: `SELECT COUNT(*) FROM Patients;` returns 10
- [ ] Open `01-walkthrough-quality.sql` in VS Code
- [ ] Have Claude.ai (or Copilot) open in a second tab for the AI demo
- [ ] Open the deck in Presenter View
- [ ] Confirm Zoom is recording

---

## Session Flow (75 to 80 min)

| Time | Block | Slides |
|---|---|---|
| 0:00 to 0:05 | Welcome, recap of Week 10, today's shift | 1 to 3 |
| 0:05 to 0:12 | Profiling vs quality, the six dimensions, schema | 4 to 6 |
| 0:12 to 0:22 | The check pattern + completeness with thresholds | 7 to 8 |
| 0:22 to 0:34 | Duplicate detection (the big new skill) | 9 to 10 |
| 0:34 to 0:44 | Validity, consistency, timeliness | 11 to 13 |
| 0:44 to 0:54 | The scorecard + thresholds + alerting + AI demo | 14 to 18 |
| 0:54 to 1:10 | Hands-on exercises (1 to 4 together) | 19 to 20 |
| 1:10 to 1:20 | Recap, what's next, Q&A | 21 to 22 |

If time slips, cut the timeliness slide (13) first, then condense alerting (17).

---

## Key Messages

1. **A profile describes, a check judges.** The output of a check is a verdict, not a description.
2. **The six dimensions are the map.** Completeness, uniqueness, validity, consistency, accuracy, timeliness.
3. **The scorecard is the deliverable.** One query, one glance, whole-database health.
4. **Constraints are not a substitute for checks.** Real data arrives around the constraints.
5. **AI drafts the suite, you own the thresholds.** A threshold is a business decision.

---

## The Duplicate Detection Moment (Slides 9 to 10)

This is the headline new skill versus last week. Make the distinction explicit:

- **Last week**, uniqueness meant `COUNT(DISTINCT col)`, how many distinct values.
- **This week**, uniqueness means finding actual duplicate *rows* and deciding what to do with them.

Two patterns to land:

1. `GROUP BY ... HAVING COUNT(*) > 1` **finds** duplicates.
2. `ROW_NUMBER() OVER (PARTITION BY ...)` **lets you keep one and drop the rest.**

The ROW_NUMBER pattern connects forward to Week 12 (Window Functions). Tease that.

---

## AI Demo Script (Slide 18)

Open Claude.ai. Show the structured five-part prompt for a quality suite:

> I'm using T-SQL on SQL Server.
>
> Table Admissions has columns: AdmissionID INT PK, PatientID INT NOT NULL, WardID INT NULL, AdmissionDate DATETIME NOT NULL, DischargeDate DATETIME NULL, AdmissionType NVARCHAR(50), Diagnosis NVARCHAR(200).
>
> Generate a data quality check suite as one UNION ALL scorecard. Each check returns rule_name, violations (int), status ('PASS'/'FAIL'). Cover completeness, uniqueness, validity, and consistency. After the suite, tell me which dimension each check covers and name any check you could NOT write from the schema alone.

Run the result live. The payoff line: AI will name accuracy as something it *cannot* check from the schema. That is the teachable moment about the limits of automated quality.

---

## Common Questions and How To Answer

**"If the FK already stops orphans, why check for them?"**
> Because constraints only protect data that comes in through the front door. Bulk inserts, ETL pipelines, and restored backups can all introduce rows that bypass or temporarily disable constraints. The check is cheap insurance.

**"How do I pick a threshold?"**
> Start from the column's role. Keys and mandatory fields: zero tolerance. Optional fields: document the expected rate and alert on swings. The number matters less than writing down *why* you chose it.

**"What's the difference between this and last week?"**
> Last week was descriptive: what does this data look like? This week is evaluative: does this data meet our standard, yes or no? Same queries underneath, different purpose on top.

**"Can I delete duplicates directly?"**
> Yes, with `DELETE FROM cte WHERE rn > 1` using the ROW_NUMBER pattern. But tag and eyeball them first. Deleting data is a one-way door.

**"How would this run automatically?"**
> Save the scorecard query as a view or a stored procedure, schedule it (SQL Agent job, or an orchestrator like Airflow or ADF), and alert when any row shows FAIL. We're not building that today, but that's where this leads.

---

## Exercise Walkthrough Script

Walk through 1 to 4 in class. The rest are homework.

**Exercise 1 (Completeness check)** - 3 min. Note it FAILS (Ward A has a NULL Site). A failing check that catches a real gap is a *success*, not an error. Make that point.

**Exercise 2 (Duplicate detection)** - 4 min. Returns zero rows on clean data. Emphasise the pattern transfers to messy imports. Don't let "it returned nothing" feel like failure.

**Exercise 3 (Validity range check)** - 3 min. Codifies a business rule (1 to 200 beds). Mention the optional NULL-handling refinement.

**Exercise 4 (Referential check)** - 4 min. The LEFT JOIN ... WHERE parent IS NULL pattern. Reinforce why you check even when the FK exists.

---

## If Things Go Wrong

| Problem | Fallback |
|---|---|
| Codespace won't start | Run against any SQL Server; only `ROW_NUMBER`/`STDEV` syntax is engine-specific |
| Live AI demo fails | Talk through the prompt structure using the slide; show the solution file output |
| Running over time | Skip exercises 5 to 7, point to them as homework, end on time |
| Quiet room | Ask: "what's one duplicate or gap you've hit in real data?" |

---

## Post-Session Actions

- [ ] Push the deck and SQL files to the bootcamp repo under `week-11/`
- [ ] Post the cheat sheet in the cohort channel
- [ ] Share the Zoom recording link
- [ ] Tease Week 12: "We used ROW_NUMBER today. Next week, Window Functions, the full family."

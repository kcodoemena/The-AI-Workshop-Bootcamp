# Data Quality Cheat Sheet | Week 11

The six dimensions, the check pattern, duplicate detection, and the scorecard. Pin this next to last week's profiling sheet.

---

## The Six Dimensions of Data Quality

A profile *describes* data. A quality check *judges* it against a rule.

| Dimension | Question | Typical check |
|---|---|---|
| **Completeness** | Is anything missing? | `SUM(CASE WHEN col IS NULL...)` vs a threshold |
| **Uniqueness** | Are there duplicates? | `GROUP BY ... HAVING COUNT(*) > 1` |
| **Validity** | Does it match the rules? | format / range / allowed-set checks |
| **Consistency** | Do related fields agree? | cross-field + referential checks |
| **Accuracy** | Does it match reality? | compare to a trusted reference |
| **Timeliness** | Is it fresh enough? | `DATEDIFF` on the latest timestamp |

Accuracy is the hardest and often needs a reference dataset. The other five you can usually check in SQL alone.

---

## The Quality Check Pattern

Every check returns the **same three columns**. That consistency is what lets checks stack into a scorecard.

```sql
SELECT
    'Table.rule description'                           AS rule_name,
    SUM(CASE WHEN <violation condition> THEN 1 ELSE 0 END) AS violations,
    CASE
        WHEN SUM(CASE WHEN <violation condition> THEN 1 ELSE 0 END) = 0
        THEN 'PASS' ELSE 'FAIL'
    END                                                AS status
FROM YourTable;
```

---

## Completeness With a Threshold

Not every NULL is a failure. Some columns are *legitimately* empty (a discharge reason while the patient is still admitted). Set a tolerance.

```sql
SELECT
    'col <= 50% null' AS rule_name,
    CAST(100.0 * SUM(CASE WHEN col IS NULL THEN 1 ELSE 0 END) / COUNT(*) AS DECIMAL(5,2)) AS pct_null,
    CASE WHEN 100.0 * SUM(CASE WHEN col IS NULL THEN 1 ELSE 0 END) / COUNT(*) <= 50
         THEN 'PASS' ELSE 'FAIL' END AS status
FROM YourTable;
```

---

## Duplicate Detection (the headline skill)

**Find duplicate values**

```sql
SELECT key_col, COUNT(*) AS times_seen
FROM YourTable
GROUP BY key_col
HAVING COUNT(*) > 1;
```

**Find duplicate entities across several columns**

```sql
SELECT FirstName, LastName, DateOfBirth, COUNT(*) AS record_count
FROM Patients
GROUP BY FirstName, LastName, DateOfBirth
HAVING COUNT(*) > 1;
```

**Tag duplicates to keep one (ROW_NUMBER)**

```sql
WITH ranked AS (
    SELECT *,
        ROW_NUMBER() OVER (PARTITION BY key_col ORDER BY created_at) AS rn
    FROM YourTable
)
SELECT *, CASE WHEN rn = 1 THEN 'KEEP' ELSE 'DROP' END AS action
FROM ranked;
-- To actually remove: DELETE FROM ranked WHERE rn > 1;
```

`HAVING COUNT(*) > 1` finds them. `ROW_NUMBER()` lets you remove them while keeping one.

---

## Consistency Checks

**Cross-field (logical impossibility)**

```sql
SUM(CASE WHEN DischargeDate < AdmissionDate THEN 1 ELSE 0 END)
```

**Referential integrity (orphans)**

```sql
SELECT COUNT(*) AS orphans
FROM Child c
LEFT JOIN Parent p ON c.parent_id = p.id
WHERE p.id IS NULL;
```

---

## The Quality Scorecard

Stack every check with `UNION ALL`. Each branch must project the **same columns in the same order**. This is the artifact you schedule and watch.

```sql
SELECT 'rule 1' AS rule_name, <violations> AS violations, <status> AS status FROM T1
UNION ALL
SELECT 'rule 2',             <violations>,                <status>         FROM T2
UNION ALL
SELECT 'rule 3',             <violations>,                <status>         FROM T3
ORDER BY status DESC, rule_name;   -- failures float to the top
```

---

## Setting Thresholds

| Column type | Sensible default |
|---|---|
| Primary / foreign keys | 0% NULL, 0 duplicates (hard fail) |
| Mandatory business fields | 0 to 1% NULL |
| Optional fields | document the expected NULL rate, alert on big swings |
| Reference / lookup values | 100% must be in the allowed set |

A threshold is a decision, not a guess. Write down *why* you chose it.

---

## The AI Quality-Rule Prompt

```
DIALECT     T-SQL on SQL Server.
SCHEMA      <paste the table DDL>
GOAL        Generate a quality check suite as one UNION ALL scorecard.
            Each check returns: rule_name, violations (int),
            status ('PASS'/'FAIL').
DIMENSIONS  Cover completeness, uniqueness, validity, consistency.
VERIFY      Say which dimension each check covers, and name any check
            you could NOT write from the schema alone.
```

That last line is the gold. AI naming the checks it *can't* write (accuracy, business-rule consistency) tells you where you need a human or a reference dataset.

---

## Five Data Quality Mistakes To Avoid

1. **Treating every NULL as a failure.** Some columns are meant to be empty. Use thresholds.
2. **Checking uniqueness on one column when the entity spans several.** A person is name + DOB, not just an ID.
3. **Trusting FK constraints to mean "no orphans".** Bulk loads and ETL bypass them. Check anyway.
4. **Running checks once.** Quality drifts. Schedule the scorecard.
5. **No threshold written down.** "Looks fine" is not a quality standard. State the rule and the tolerance.

---

## Quick Reference: When To Use What

| You want to... | Use |
|---|---|
| Count missing values | `SUM(CASE WHEN col IS NULL...)` |
| Find duplicate rows | `GROUP BY ... HAVING COUNT(*) > 1` |
| Keep one of each duplicate | `ROW_NUMBER() OVER (PARTITION BY ...)` |
| Check a value is in a set | `col NOT IN (...)` |
| Find orphan references | `LEFT JOIN ... WHERE parent IS NULL` |
| Combine many checks | `UNION ALL` into a scorecard |
